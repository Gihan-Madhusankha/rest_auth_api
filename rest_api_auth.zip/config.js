module.exports = {
    accessTokenSecret: 'myAccessTokenSecret',
    accessTokenExpiresIn: '1h',

    refreshTokenSecret: 'myRefreshTokenSecret',
    refreshTokenExpiresIn: '1w',

    cacheTemporaryTokenPrefix: 'temporaryToken:',
    cacheTemporaryTokenExpiresInSeconds: 180
}